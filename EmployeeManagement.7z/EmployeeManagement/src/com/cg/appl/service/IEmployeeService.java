package com.cg.appl.service;

import java.util.List;

import com.cg.appl.dto.Employee;
import com.cg.appl.exception.EmployeeException;

public interface IEmployeeService {
	public int addEmployee(Employee emp)  throws EmployeeException;
	public List<Employee> showAll() throws EmployeeException;
	public Employee getEmployeeDetail(int id) throws EmployeeException;
	public boolean updateEmployee(Employee emp1) throws EmployeeException;
}
