package com.cg.appl.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.appl.dto.Employee;
import com.cg.appl.exception.EmployeeException;
import com.cg.appl.util.DbUtil;

public class EmployeeDaoImpl implements IEmployeeDao {
	
	
	@Override
	public int addEmployee(Employee emp) throws EmployeeException {
		Connection conn=null;
		PreparedStatement pstm=null;
		int msg=0;
		int empId=getEmployee();
		String query="INSERT INTO EMPLOYEEMANAGEMENT VALUES(?,?,?,?)";
		
			try {
				conn=DbUtil.obtainConnection();
				pstm=conn.prepareStatement(query);
				pstm.setInt(1,empId);
				pstm.setString(2,emp.getEmpName());
				pstm.setString(3,emp.getEmpQualification());
				pstm.setDouble(4,emp.getEmpSalary());
				
				int status=pstm.executeUpdate();
				if(status==1){
					msg=empId;
				}
			
		} catch (EmployeeException |SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new EmployeeException("Problem in insert");
		}finally{
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return msg;
	}

	@Override
	public List<Employee> showAll() throws EmployeeException {
		Connection conn=null;
		PreparedStatement pstm=null;
		List<Employee> myEmp=new ArrayList<Employee>();
		
		String query="SELECT emp_id,emp_name,emp_qual,emp_sal FROM EMPLOYEEMANAGEMENT";
		try {
			conn=DbUtil.obtainConnection();
			pstm=conn.prepareStatement(query);
			ResultSet res=pstm.executeQuery();
			while(res.next()){
				Employee e=new Employee();
				e.setEmpid(res.getInt("emp_id"));
				e.setEmpName(res.getString("emp_name"));
				e.setEmpQualification(res.getString("emp_qual"));
				e.setEmpSalary(res.getDouble("emp_sal"));
				
				myEmp.add(e);
				
			}
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new EmployeeException("Problem in show");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return myEmp;
	}
	
	public int getEmployee(){
		int empId=0;
		Connection conn=null;
		PreparedStatement pstm=null;
		
		String query="SELECT empm_id_seq.NEXTVAL FROM DUAL";
		try {
			conn=DbUtil.obtainConnection();
			pstm=conn.prepareStatement(query);
			ResultSet res=pstm.executeQuery();
			while(res.next()){
				empId=res.getInt(1);
			}
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return empId;
	}

	@Override
	public Employee getEmployeeDetail(int id) {
		Connection conn=null;
		PreparedStatement pstm=null;
		Employee emp=new Employee();
		
		String query="SELECT emp_id,emp_name,emp_qual,emp_sal FROM EMPLOYEEMANAGEMENT where emp_id=?";
		try {
			conn=DbUtil.obtainConnection();
			pstm=conn.prepareStatement(query);
			pstm.setInt(1, id);
			ResultSet res=pstm.executeQuery();
			while(res.next()){
				
				emp.setEmpid(res.getInt("emp_id"));
				emp.setEmpName(res.getString("emp_name"));
				emp.setEmpQualification(res.getString("emp_qual"));
				emp.setEmpSalary(res.getDouble("emp_sal"));
				
			}
			
		} catch (EmployeeException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return emp;
	}
	
	public boolean updateEmployee(Employee emp1) throws EmployeeException  {
		Connection conn=null;
		PreparedStatement pstm=null;
		int empId=emp1.getEmpid();
		String query="update EMPLOYEEMANAGEMENT set emp_name=?,emp_qual=?,emp_sal=? Where emp_id=?";
		
		try {
			conn=DbUtil.obtainConnection();
			pstm=conn.prepareStatement(query);
			pstm.setString(1,emp1.getEmpName());
			pstm.setString(2,emp1.getEmpQualification());
			pstm.setDouble(3,emp1.getEmpSalary());
			pstm.setInt(4,empId);
			
			int status=pstm.executeUpdate();
			if(status==1){
				System.out.println("DATA UPDATED");
				return true;
			}else{
				System.out.println("data not updated");
			}
		} catch (EmployeeException e) {
			e.printStackTrace();
			throw new EmployeeException("Problem in update");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return false;
	}
		
}
