package com.cg.TicketBookAppl.service;

import java.util.List;

import com.cg.TicketBookAppl.dao.ShowDao;
import com.cg.TicketBookAppl.dao.ShowDaoImpl;
import com.cg.TicketBookAppl.dto.Show;
import com.cg.TicketBookAppl.exception.ShowException;

public class ShowServiceImpl implements ShowService{
	ShowDao dao;
	public ShowServiceImpl() {
		dao=new ShowDaoImpl();
	}

	@Override
	public List<Show> showAll() throws ShowException {
		// TODO Auto-generated method stub
		return dao.showAll();
	}

	@Override
	public Show getShowDetail(String id) throws ShowException {
		// TODO Auto-generated method stub
		return dao.getShowDetail(id);
	}

	@Override
	public boolean updateShow(String showName, String custName, int seats1,
			int pNo, int price1, int avlSeats1) throws ShowException {
		// TODO Auto-generated method stub
		return dao.updateShow(showName, custName, seats1, pNo, price1, avlSeats1);
	}
	
	

}
