package com.cg.TicketBookAppl.service;

import java.util.List;

import com.cg.TicketBookAppl.dto.Show;
import com.cg.TicketBookAppl.exception.ShowException;

public interface ShowService {
	public List<Show> showAll() throws ShowException;
	public Show getShowDetail(String id) throws ShowException ;
	public boolean updateShow(String showName,String custName,int seats1,int pNo,int price1,int avlSeats1) throws ShowException ;
}
