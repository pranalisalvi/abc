package com.cg.TicketBookAppl.exception;

public class ShowException extends Exception{

	public ShowException() {
		super();
	}

	public ShowException(String msg) {
		super(msg);
		
	}


}
