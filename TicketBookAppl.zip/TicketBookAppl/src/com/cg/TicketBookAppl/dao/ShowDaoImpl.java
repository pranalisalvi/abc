package com.cg.TicketBookAppl.dao;

import java.sql.Connection; 
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



import java.util.ArrayList;
import java.util.List;

import com.cg.TicketBookAppl.dto.Show;
import com.cg.TicketBookAppl.exception.ShowException;
import com.cg.TicketBookAppl.util.DbUtil;




public class ShowDaoImpl implements ShowDao{

	@Override
	public List<Show> showAll() throws ShowException  {
		
		
		Connection conn=null;
		PreparedStatement pstm=null;
		List<Show> myShow=new ArrayList<Show>();
		
		String query="select ShowName,Location,ShowDate,AvSeats,PriceTicket,ShowId from SHOWDETAILS";
		try {
			conn=DbUtil.obtainConnection();
			pstm=conn.prepareStatement(query);
			ResultSet res=pstm.executeQuery();
			while(res.next()){
				Show s=new Show();
				s.setShowName(res.getString("ShowName"));
				s.setLocation(res.getString("Location"));
				s.setShowDate(res.getDate("ShowDate"));
				s.setAvSeats(res.getInt("AvSeats"));
				s.setPrice(res.getInt("PriceTicket"));
				s.setShowId(res.getString("ShowId"));
				myShow.add(s);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ShowException("Problem in show");
		}finally{
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		
		return myShow;
	}

	@Override
	public Show getShowDetail(String id) throws ShowException {
		Connection conn=null;
		PreparedStatement pstm=null;
		Show s1=new Show();
		
		String query="SELECT ShowName,AvSeats,PriceTicket,ShowId FROM SHOWDETAILS where ShowId =?";
		try {
			conn=DbUtil.obtainConnection();
			pstm=conn.prepareStatement(query);
			pstm.setString(1, id);
			ResultSet res=pstm.executeQuery();
			while(res.next()){
				
				s1.setShowName(res.getString("ShowName"));
				s1.setAvSeats(res.getInt("AvSeats"));
				s1.setPrice(res.getInt("PriceTicket"));
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		
		return s1;
	}

	@Override
	public boolean updateShow(String showName, String custName, int seats1,
			int pNo, int price1, int avlSeats1) throws ShowException {
		Show s2=new Show();
		int AvSeats=s2.getAvSeats();
		int seats=0;
		String ShowId=s2.getShowId();
		Connection conn=null;
		PreparedStatement pstm=null;
		
		String query="update ShowDetails set AvSeats=? Where ShowId=?";
		
		try {
			conn=DbUtil.obtainConnection();
			pstm=conn.prepareStatement(query);
			
			
			int newSeats= AvSeats-seats ;

			pstm.setInt(1, newSeats);

			pstm.setString(2, ShowId);
			int status=pstm.executeUpdate();
			if(status==1){
				System.out.println("DATA UPDATED");
				return true;
			}else{
				System.out.println("data not updated");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return false;
	}
		

	
	
}
