package com.cg.TicketBookAppl.controller;

import java.io.IOException; 
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.TicketBookAppl.dto.Show;
import com.cg.TicketBookAppl.exception.ShowException;
import com.cg.TicketBookAppl.service.ShowService;
import com.cg.TicketBookAppl.service.ShowServiceImpl;

@WebServlet("*.do")
public class ShowController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ShowService service;
	
	
	
	public void init(ServletConfig config) throws ServletException {
		service=new ShowServiceImpl();
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}


	private void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String path= request.getServletPath();
		//System.out.println(path);
		if(path.equals("/showController.do")){  
			List<Show> myList = null;
			try {
				myList = service.showAll();
			} catch (ShowException e) {
				e.printStackTrace();
			}
			//System.out.println(myList);
			request.setAttribute("data",myList);        
			RequestDispatcher res=request.getRequestDispatcher("showDetails.jsp");
			res.forward(request, response);
		}else if(path.equals("/update.do")){
			//System.out.println("update.....");
			String data=request.getQueryString();
			String id=data.substring(3, 7);
			
		Show sData=null;
			try {
				sData = service.getShowDetail(id);
			} catch (ShowException e) {
				
				e.printStackTrace();
			}
			//System.out.println(sData);
			request.setAttribute("showData",sData);
			RequestDispatcher res=request.getRequestDispatcher("updateShow.jsp");
			res.forward(request, response);
			
		}else if(path.equals("/updatedata.do")){
			//System.out.println("updatedata...");
			
			String showName=request.getParameter("sname");
			String avlSeats=request.getParameter("sseats");
			String price=request.getParameter("sprice");
			String custName=request.getParameter("cName");
			String phoneNo=request.getParameter("cPhoneno");
			String seats=request.getParameter("seats");
			
			
			int seats1= Integer.parseInt(seats);
			int pNo= Integer.parseInt(phoneNo);
			int price1=Integer.parseInt(price);
			int avlSeats1=Integer.parseInt(avlSeats);
		
			
			 try {
				service.updateShow(showName,custName,seats1,pNo,price1,avlSeats1);
			} catch (ShowException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			request.setAttribute("showName",showName);
			request.setAttribute("custmerName", custName);
			request.setAttribute("seats",seats1);
			request.setAttribute("phoneno1",pNo);
			 RequestDispatcher res=request.getRequestDispatcher("/success.do");
				res.forward(request, response);
		}
		

}
}
