package com.cg.appl.service;

import com.cg.appl.dto.BillDetails;
import com.cg.appl.exception.BillException;



public interface BillService {
	public String getConsumerDetails(String UserName,String password) throws BillException; 
	boolean isUserAuthenticated(String userName,String password) throws BillException;
	//end of login
	public int addBillDetail(int cons_num, BillDetails billDetail) throws BillException;
}
