package com.cg.appl.service;

import com.cg.appl.dao.BillDao;
import com.cg.appl.dao.BillDaoImpl;
import com.cg.appl.dto.BillDetails;
import com.cg.appl.exception.BillException;


public class BillServiceImpl implements BillService{

	BillDao dao= new BillDaoImpl();

	@Override
	public String getConsumerDetails(String userName, String password) throws BillException {
		
		return dao.getConsumerDetail(userName, password);
	}

	@Override
	public boolean isUserAuthenticated(String userName, String password) throws BillException {
		// TODO Auto-generated method stub
 String pwd=dao.getConsumerDetail(userName,password);
		
		if(pwd.equals(password)){
			return true;
		}else{
			return false;
		}
		
	} //end of login

	@Override
	public int addBillDetail(int cons_num, BillDetails billDetail)
			throws BillException {
		// TODO Auto-generated method stub
		return dao.addBillDetail(cons_num, billDetail);
	}
}


