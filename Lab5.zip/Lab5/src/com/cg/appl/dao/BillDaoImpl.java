package com.cg.appl.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.appl.dto.BillDetails;
import com.cg.appl.exception.BillException;
import com.cg.appl.util.DbUtil;

public class BillDaoImpl implements BillDao {

	@Override
	public String getConsumerDetail(String userName, String password)
			throws BillException {
		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		String pwd = "";

		String query = "SELECT PASSWORD FROM USERMASTER WHERE USERNAME=?";
		try {
			conn = DbUtil.obtainConnection();
			pstm = conn.prepareStatement(query);
			pstm.setString(1, userName);
			rs = pstm.executeQuery();

			if (rs.next()) {
				String password1 = rs.getString("PASSWORD");

				return password1;

			} else {
				throw new BillException("Username wrong");

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pstm != null) {
					pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				throw new BillException("Jdbc connection closing failed");
			}

		}
		return pwd;

	} // end of login

	public int addBillDetail(int cons_num, BillDetails billDetail)
			throws BillException {
		Connection conn = null;
		PreparedStatement pstm = null;

		String checkQry = "SELECT consumer_num FROM Consumers";

		boolean flag = false;

		try {
			conn = DbUtil.obtainConnection();

			pstm = conn.prepareStatement(checkQry);

			ResultSet res2 = pstm.executeQuery();

			while (res2.next()) {

				int conNum = res2.getInt(1);

				if (conNum == cons_num) {

					flag = true;

					break;

				}

			}

		} catch (SQLException e1) {

			// TODO Auto-generated catch block

			e1.printStackTrace();

		}

		if (flag == true) {

			PreparedStatement stmt = null;

			int bill_Id = getBillId();

			String insQry = "INSERT INTO BillDetails VALUES(?,?,?,?,?,?)";

			int msg = 0;

			try {

				 conn= DbUtil.obtainConnection();

				stmt = conn.prepareStatement(insQry);

				stmt.setInt(1, bill_Id);

				stmt.setInt(2, cons_num);

				stmt.setInt(3, billDetail.getCurntReading());

				stmt.setInt(4, billDetail.getUnitConsumed());

				stmt.setFloat(5, billDetail.getNetAmnt());

				stmt.setDate(6, billDetail.getBillDate());

				int status = stmt.executeUpdate();

				if (status == 1) {

					msg = bill_Id;

				}

			}

			catch (SQLException e) {

				// TODO Auto-generated catch block

				e.printStackTrace();

				throw new BillException("Problem in insert");

			}

			return msg;

		}

		else {

			throw new BillException("Consumer num does not exist");

		}

	}

	public int getBillId() {

		int billId = 0;
		Connection conn = null;
		PreparedStatement pstm2 = null;

		String qry = "SELECT seq_bill_num.NEXTVAL FROM DUAL";

		try {

			conn = DbUtil.obtainConnection();

			pstm2 = conn.prepareStatement(qry);

			ResultSet res = pstm2.executeQuery();

			while (res.next()) {

				billId = res.getInt(1);

			}

		} catch (SQLException e) {

			e.printStackTrace();

		}

		return billId;

	}

}
