package com.cg.appl.dao;

import com.cg.appl.dto.BillDetails;
import com.cg.appl.exception.BillException;

public interface BillDao {
	String getConsumerDetail(String userName,String password) throws BillException;
	//end of login
	public int addBillDetail(int cons_num, BillDetails billDetail)throws BillException;
}
